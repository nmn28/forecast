package com.example.forecast.ui.ai.helpers

object DataHolder {
    var docPath: String = ""
}