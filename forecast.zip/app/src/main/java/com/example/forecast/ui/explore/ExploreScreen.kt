package com.example.forecast.ui.explore

import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier

@Composable
fun ExploreScreen() {
    // Your Watchlists screen content goes here
    Text(
        text = "Explore Screen Content",
        modifier = Modifier.fillMaxSize()
    )
}