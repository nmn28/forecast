package com.example.forecast.ui.instructions

import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier

@Composable
fun InstructionsScreen() {
    // Your Watchlists screen content goes here
    Text(
        text = "Instructions Screen Content",
        modifier = Modifier.fillMaxSize()
    )
}