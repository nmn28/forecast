package com.example.forecast.ui.ai.constants

const val baseUrlOpenAI = "https://api.openai.com/"
const val textCompletionsEndpoint = "v1/completions"
const val textCompletionsTurboEndpoint = "v1/chat/completions"