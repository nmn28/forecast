package com.example.forecast.ui.profile

class ProfileViewModel {
}