package com.example.forecast.ui.ai.constants

const val conversationCollection: String = "conversations";
const val messageCollection: String = "messages";