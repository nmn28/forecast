package com.example.forecast.ui.instructions

class InstructionsViewModel {
}