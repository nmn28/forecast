package com.example.forecast.ui.ai.data

class filler {
}