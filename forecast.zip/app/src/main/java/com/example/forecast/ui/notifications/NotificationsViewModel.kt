package com.example.forecast.ui.notifications

class NotificationsViewModel {
}