package com.example.forecast.ui.watchlists

import androidx.lifecycle.ViewModel

class WatchlistsViewModel : ViewModel() {
    // Your ViewModel logic goes here
}