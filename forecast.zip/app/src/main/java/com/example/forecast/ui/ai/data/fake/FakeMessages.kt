package com.example.forecast.ui.ai.data.fake
import com.example.forecast.ui.ai.models.MessageModel
import java.util.*

val fakeMessages: List<MessageModel> = listOf(
    MessageModel(
        question = "Who is lambiengcode?",
        answer = "I'm Kai (lambiengcode), currently working as the Technical Leader at Askany and Waodate. Computador Also, I'm a freelancer. If you have a need for a mobile application or website, contact me by email: lambiengcode@gmail.com",
        createdAt = Date()
    ),
    MessageModel(
        question = "Who is lambiengcode?",
        answer = "I'm Kai (lambiengcode), currently working as the Technical Leader at Askany and Waodate. Computador Also, I'm a freelancer. If you have a need for a mobile application or website, contact me by email: lambiengcode@gmail.com",
        createdAt = Date()
    ),
)