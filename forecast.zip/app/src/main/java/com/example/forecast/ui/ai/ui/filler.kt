package com.example.forecast.ui.ai.ui

class filler {
}