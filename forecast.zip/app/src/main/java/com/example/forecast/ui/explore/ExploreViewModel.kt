package com.example.forecast.ui.explore

import androidx.lifecycle.ViewModel

class ExploreViewModel : ViewModel() {
    // Your ViewModel logic goes here
}